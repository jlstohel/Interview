﻿using JackStohelInterviewTest1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace JackStohelInterviewTest1.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Mytest()
        {
            // Instatiated a new Author object
            Author bill = new Author();
            bill.FirstName = "Bill";
            bill.LastName = "Robertson";

            // Instatiated multiple new Book objects.
            Book one = new Book();
            one.Name = "First Book in the Series";

            Book two = new Book();
            two.Name = "Second Book in the Series";

            Book three = new Book();
            three.Name = "Third Book in the Series";

            Book four = new Book();
            four.Name = "Fourth Book in the Series";

            // adding Book objects to a list.
            List<Book> books = new List<Book>();
            books.Add(one);
            books.Add(two);
            books.Add(three);
            books.Add(four);

            // adding all objects to the view model
            BookList list = new BookList();
            list.author = bill;
            list.books = books;

            // sending the view model to the view
            return View(list);
        }
    }
}