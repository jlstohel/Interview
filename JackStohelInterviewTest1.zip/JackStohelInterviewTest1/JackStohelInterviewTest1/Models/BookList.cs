﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JackStohelInterviewTest1.Models
{
    // Creating the BookList View Model in order to send two objects to the view.
    public class BookList
    {
        public Author author { get; set; }
        public List<Book> books { get; set; }
    }
}