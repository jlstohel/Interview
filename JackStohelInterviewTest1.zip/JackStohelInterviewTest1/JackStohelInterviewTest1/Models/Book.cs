﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JackStohelInterviewTest1.Models
{
    // Creating a Book class with an ID and name.  ID is set as the classname + ID in order to be easily used in code first database creation for the ID to be the primary key.
    public class Book
    {
        public int BookID { get; set; }
        public string Name { get; set; }
        
    }
}