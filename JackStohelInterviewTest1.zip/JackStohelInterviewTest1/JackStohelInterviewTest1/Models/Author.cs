﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JackStohelInterviewTest1.Models
{
    // Creating the Author class with an ID and first and last names.  ID is set as classname + ID in order to be easily used in code first database creation as
    // a primary key.
    public class Author
    {
        public int AuthorID { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
    }
}